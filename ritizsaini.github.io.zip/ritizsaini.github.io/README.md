<h1>Academic Website Template</h1>

<p>This is a free thing. You may download this and use it to create your own website(s), as long as you abide by the license restrictions.</p>

<p>Enjoy it and if you like this, drop me a line and let me know!</p>

<div>Icons made by <a href="https://www.flaticon.com/authors/freepik" title="Freepik">Freepik</a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com</a> messages.attribution.is_licensed_by <a href="http://creativecommons.org/licenses/by/3.0/" title="Creative Commons BY 3.0" target="_blank">CC 3.0 BY</a></div>
